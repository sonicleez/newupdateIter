import React from 'react';

interface AdminPanelProps {
  onLogout: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = () => {
  return null;
};

export default AdminPanel;
